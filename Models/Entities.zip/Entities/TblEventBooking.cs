﻿using System;


namespace Semester03.Models.Entities
{
    public partial class TblEventBooking
    {
        public int EventBookingId { get; set; }
        public int EventBookingTenantId { get; set; }
        public int EventBookingUserId { get; set; }
        public int EventBookingEventId { get; set; }
        public decimal? EventBookingTotalCost { get; set; }
        public int? EventBookingPaymentStatus { get; set; }
        public string EventBookingNotes { get; set; }
        public DateTime? EventBookingCreatedDate { get; set; }


        public virtual TblEvent EventBookingEvent { get; set; }
        public virtual TblTenant EventBookingTenant { get; set; }
        public virtual TblUser EventBookingUser { get; set; }
    }
}